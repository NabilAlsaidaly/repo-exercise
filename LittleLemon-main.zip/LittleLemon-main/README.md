# LittleLemon
Capstone project for Corsera


urls to use

restaurant/
restaurant/menu
restaurant/booking
